package com.compare.show.model
data class SelectMobileListModel(
    val mobileId: Int = 0,
    val mobileName: String = ""
)