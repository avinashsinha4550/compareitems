package com.compare.show.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposematerial.ui.theme.Teal200
import com.example.jetpackcomposematerial.ui.theme.attr.Elevations
import com.example.jetpackcomposematerial.ui.theme.attr.LocalElevations
import com.example.jetpackcomposematerial.ui.theme.attr.LocalPaddings
import com.example.jetpackcomposematerial.ui.theme.attr.Paddings
import com.example.jetpackcomposematerial.ui.theme.red200
import com.example.jetpackcomposematerial.ui.theme.red500
import com.example.jetpackcomposematerial.ui.theme.red700

//private val DarkColorPalette = darkColors(
//    primary = red200,
//    primaryVariant = red700,
//    secondary = Teal200
//)
//
//private val LightColorPalette = lightColors(
//    primary = red500,
//    primaryVariant = red700,
//    secondary = Teal200

    /* Other default colors to override
    background = Color.White,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    */
//)

@Composable
fun JetpackComposeMaterialTheme(
    lightColorPalette: Colors,
    darkColorPalette: Colors,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable() () -> Unit
) {
    val colors = if (darkTheme) {
        darkColorPalette
    } else {
        lightColorPalette
    }
    CompositionLocalProvider(
        LocalPaddings provides Paddings(),
        LocalElevations provides Elevations(card = 8.dp)
    ) {
        MaterialTheme(
            colors = colors,
//            typography = Typography,
//            shapes = Shapes,
            content = content
        )
    }
}

object JetpackComposeMaterialTheme {
    /**
     * Proxy to [MaterialTheme]
     */
    val colors: Colors
        @Composable
        get() = MaterialTheme.colors

    /**
     * Proxy to [MaterialTheme]
     */
    val typography: Typography
        @Composable
        get() = MaterialTheme.typography

    /**
     * Proxy to [MaterialTheme]
     */
    val shapes: Shapes
        @Composable
        get() = MaterialTheme.shapes

    /**
     * Retrieves the current [Paddings].
     */
    val paddings: Paddings
        @Composable
        get() = LocalPaddings.current

    /**
     * Retrieves the current [Paddings].
     */
    val elevations: Elevations
        @Composable
        get() = LocalElevations.current

}
