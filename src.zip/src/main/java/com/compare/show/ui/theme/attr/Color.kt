package com.example.jetpackcomposematerial.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFFFFFFFF)

val yellow200 = Color(0xffffeb46)
val yellow400 = Color(0xffffc000)
val yellow500 = Color(0xffffde03)
val yellowDarkPrimary = Color(0xff242316)
val yellowLightPrimary = Color(0xFFFFFFFF)

val blue200 = Color(0xff91a4fc)
val blue700 = Color(0xff0336ff)
val blue800 = Color(0xff0035c9)
val blueDarkPrimary = Color(0xff1c1d24)
val blueLightPrimary = Color(0xFFFFFFFF)

val pink200 = Color(0xffff7597)
val pink500 = Color(0xffff0266)
val pink600 = Color(0xffd8004d)
val pinkDarkPrimary = Color(0xff24191c)
val pinkLightPrimary = Color(0xFFFFFFFF)

val red200 = Color(0xEEC20000)
val red500 = Color(0xFFC20000)
val red700 = Color(0xFFC20000)
val red800 = Color(0xFFC20000)
val redDarkPrimary = Color(0xff1c1d24)
val redLightPrimary = Color(0xFFFFFFFF)
