package com.compare.show.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

import com.compare.show.theme.JetpackComposeMaterialTheme
private val DarkColorPalette = darkColors(
    primary = Color.Red,
    primaryVariant = Color.Red,
    secondary = Color.Red
)

private val LightColorPalette = lightColors(
    primary = Color.Red,
    primaryVariant = Color.Red,
    secondary = Color.Red

    /* Other default colors to override
    background = Color.White,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    */
)

@Composable
fun NavigationDrawerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable() () -> Unit
) {
    val colors = if (darkTheme) {
        DarkColorPalette
    } else {
        LightColorPalette
    }

    MaterialTheme(
        colors = colors,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
//
//    @Composable
//    fun JetpackComposeMaterialTheme(
//        lightColorPalette: Colors,
//        darkColorPalette: Colors,
//        darkTheme: Boolean = isSystemInDarkTheme(),
//        content: @Composable() () -> Unit
//    ) {
//        val colors = if (darkTheme) {
//            darkColorPalette
//        } else {
//            lightColorPalette
//        }
//        CompositionLocalProvider(
//            LocalPaddings provides Paddings(),
//            LocalElevations provides Elevations(card = 8.dp)
//        ) {
//            MaterialTheme(
//                colors = colors,
//                typography = com.example.jetpackcomposematerial.ui.theme.Typography,
//                shapes = com.example.jetpackcomposematerial.ui.theme.Shapes,
//                content = content
//            )
//        }
//    }
//
//    object JetpackComposeMaterialTheme {
//        /**
//         * Proxy to [MaterialTheme]
//         */
//        val colors: Colors
//            @Composable
//            get() = MaterialTheme.colors
//
//        /**
//         * Proxy to [MaterialTheme]
//         */
//        val typography: Typography
//            @Composable
//            get() = MaterialTheme.typography
//
//        /**
//         * Proxy to [MaterialTheme]
//         */
//        val shapes: Shapes
//            @Composable
//            get() = MaterialTheme.shapes
//
//        /**
//         * Retrieves the current [Paddings].
//         */
//        val paddings: Paddings
//            @Composable
//            get() = LocalPaddings.current
//
//        /**
//         * Retrieves the current [Paddings].
//         */
//        val elevations: Elevations
//            @Composable
//            get() = LocalElevations.current
//
//    }

}